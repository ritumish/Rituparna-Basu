(function() {
var toc =  [{"name":"Introduction to Jira","type":"item","url":"Jira_Book/Jira_Installation/Jira_Installation.htm"},{"name":"Creating a task in Jira","type":"item","url":"Jira_Book/Create_task/Create_task.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();